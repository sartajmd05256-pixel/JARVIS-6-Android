package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechLauncher: androidx.activity.result.ActivityResultLauncher<Intent>? = null
    private var voiceResult: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!spoken.isNullOrBlank()) voiceResult?.invoke(spoken)
            }
        }
        setContent { JarvisApp(onSpeak = { speak(it) }, onListen = { callback -> listen(callback) }) }
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }
    private fun listen(callback: (String) -> Unit) {
        voiceResult = callback
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 12)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try { speechLauncher?.launch(intent) } catch (_: Exception) { callback("Speech recognition is unavailable on this device.") }
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

private val navy = Color(0xFF061321)
private val panel = Color(0xFF0B2035)
private val cyan = Color(0xFF30DFFF)
private val textC = Color(0xFFD8F5FF)
private val muted = Color(0xFF81AAC5)

data class ChatLine(val body: String, val isUser: Boolean)

@Composable
fun JarvisApp(onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit) {
    var input by remember { mutableStateOf("") }
    var voiceOn by remember { mutableStateOf(true) }
    val messages = remember { mutableStateListOf(ChatLine("JARVIS 6.0 online. How can I assist?", false)) }
    val reminders = remember { mutableStateListOf<String>() }

    fun reply(q: String): String {
        val lower = q.lowercase(Locale.getDefault())
        val now = Date()
        return when {
            "time" in lower -> "The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(now)
            "date" in lower || "today" in lower -> "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now)
            "hello" in lower || "hi" in lower -> "Hello. All systems are online."
            "open youtube" in lower -> { runCatching { /* website shortcut shown as text in starter */ }; "YouTube command received. Use your browser to open youtube.com." }
            "remind" in lower -> "Use the Reminders section to add a reminder. Reminders in this starter are saved during this app session."
            "help" in lower -> "I can tell time and date, respond to greetings, speak responses, and keep a simple reminder list. AI service connection is not configured yet."
            else -> "I heard: $q. JARVIS 6.0 starter is ready for an AI backend connection, which is not configured yet."
        }
    }
    fun send(q: String) {
        val clean = q.trim()
        if (clean.isEmpty()) return
        messages.add(ChatLine(clean, true))
        input = ""
        val answer = reply(clean)
        messages.add(ChatLine(answer, false))
        if (voiceOn) onSpeak(answer)
    }

    MaterialTheme {
        Column(
            Modifier.fillMaxSize().background(navy).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("J.A.R.V.I.S. 6.0", color = cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("SYSTEM ONLINE", color = muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.size(208.dp).border(1.dp, cyan.copy(alpha=.65f), CircleShape).background(navy, CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(172.dp).border(1.dp, cyan.copy(alpha=.35f), CircleShape), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(132.dp).border(1.dp, cyan.copy(alpha=.25f), CircleShape).background(Color(0xFF0C2945), CircleShape), contentAlignment = Alignment.Center) {
                        Text("JARVIS", color = cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onListen { send(it) } }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0967B6))) { Text("🎙 SPEAK") }
                OutlinedButton(onClick = { voiceOn = !voiceOn }, modifier = Modifier.weight(1f)) { Text(if (voiceOn) "🔊 VOICE ON" else "🔇 VOICE OFF", color = cyan) }
            }
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth().weight(1f), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("AI COMMUNICATION", color = cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(messages) { line ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start) {
                                Text(line.body, Modifier.widthIn(max = 290.dp).background(if (line.isUser) Color(0xFF124A82) else Color(0xFF0D2B43), RoundedCornerShape(12.dp)).padding(10.dp), color = textC)
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message JARVIS") }, singleLine = true)
                        Spacer(Modifier.width(6.dp))
                        Button(onClick = { send(input) }) { Text("SEND") }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("REMINDERS", color = cyan, fontWeight = FontWeight.Bold)
                    var reminderText by remember { mutableStateOf("") }
                    Row {
                        OutlinedTextField(value = reminderText, onValueChange = { reminderText = it }, modifier = Modifier.weight(1f), placeholder = { Text("Add reminder") }, singleLine = true)
                        Button(onClick = { if (reminderText.isNotBlank()) { reminders.add(reminderText.trim()); reminderText = "" } }) { Text("ADD") }
                    }
                    reminders.takeLast(4).forEach { Text("• $it", color = textC, modifier = Modifier.padding(top = 4.dp)) }
                    if (reminders.isEmpty()) Text("No reminders in this session", color = muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("VOICE • CHAT • REMINDERS • HUD", color = muted, fontSize = 10.sp, letterSpacing = 1.sp)
        }
    }
}
